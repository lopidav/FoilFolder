Keeps track of foils you've found!

  

Adds a "Foil Folder" buton in main menu and pause menu.
Button leads to the cardopedia-like screen but for foils!

![here's how it looks](https://i.imgur.com/rRWq9eL.png)

  

You don't need to sacrifice space on your board just for a foil collection showcase anymore.

  

And it lets you set a goal of finding all the foils. That's a very hard task tho.

  
  

## Suggestions and bug reports

Report bugs and suggestions to [me on discord (lopidav#5797)](https://discord.com/users/357116721812865025).

  

And you can find the [code of this mod on github](https://github.com/lopidav/FoilFolder)